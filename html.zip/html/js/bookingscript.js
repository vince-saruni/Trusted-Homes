// Function to open the booking form
function openBookingForm() {
  document.getElementById("bookingForm").style.display = "block";
}

// Function to close the booking form
function closeBookingForm() {
  document.getElementById("bookingForm").style.display = "none";
}
